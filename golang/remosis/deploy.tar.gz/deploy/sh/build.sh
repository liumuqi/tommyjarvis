#!/bin/bash
cp ../../remosis ../bin
