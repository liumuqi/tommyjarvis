#!/bin/bash
setsid ./bin/remosis > ./logs/monitor.log 2 >&1 &
