'Hello, World!'.length
